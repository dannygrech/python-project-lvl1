
from brain_games import engine
from brain_games.games import brain_calc


def main():
    engine.run(brain_calc)


if __name__ == '__main__':
    main()
