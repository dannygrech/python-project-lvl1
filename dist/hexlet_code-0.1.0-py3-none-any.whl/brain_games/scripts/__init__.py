def brain_games():
    return None